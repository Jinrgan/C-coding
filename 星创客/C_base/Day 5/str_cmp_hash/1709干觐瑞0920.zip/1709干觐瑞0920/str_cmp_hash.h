#include <stdio.h>
#include <string.h>

extern char * str_cmp_hash(const char * pc, const char * pr);
